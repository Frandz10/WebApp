﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Web_Portal.Filters;

namespace Web_Portal.Controllers
{
   [SessionCheck]
    public class BestPracticeController : Controller
    {
        // GET: BestPractice
        public ActionResult Index()
        {
            return View();
        }
    }
}