﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Web_Portal.Services;
using Web_Portal.Models;

namespace Web_Portal.Controllers
{
    public class AccountsController : Controller
    {
        // GET: Accounts

        dbPowerHouseEntities _db = new dbPowerHouseEntities();

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Login()
        {
            return View();
        }

        public JsonResult verifyUser(string eid, string pw ) {
            bool res = false;
            if (verifyAccount.getCredentials(eid,pw)) {
                res = true;
                HttpContext.Session["eid"] = eid;
            }
            return Json(res,JsonRequestBehavior.AllowGet);
        }

        private bool hasAccess(string eid) {
            var user = _db.tblUsers.Where(u => u.eid == eid).FirstOrDefault();

            if (user != null) {
                return true;
            }
            else {
                return false;
            }
            
        }


    }
}