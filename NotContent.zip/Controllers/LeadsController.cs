﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Web_Portal.Filters;

namespace Web_Portal.Controllers
{
    [SessionCheck]
    public class LeadsController : Controller
    {
        // GET: Leads
        public ActionResult Index()
        {
            return View();
        }
        public void openPPT() {
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo.FileName = Server.MapPath("~/Resources/One-Stop Shop - Enable People.ppsx");
            proc.Start();
        }
    }
}