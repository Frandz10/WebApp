﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Web_Portal.Models;
using Web_Portal.Filters;

namespace Web_Portal.Controllers
{
    [SessionCheck]
    public class AssessmentController : Controller
    {

        dbPowerHouseEntities _ctx = new dbPowerHouseEntities();

        // GET: Assessment

        public ActionResult OMGuidelines()
        {
            return View();
        }

        public ActionResult JourneyToIO()
        {
            return View();
        }

        public ActionResult JTIOAssessment()
        {
            return View();
        }

        public ActionResult OMAssessment()
        {
            getFY();
            return View();
        }

        public ActionResult JTIOanotherAssessment()
        {
            return View();
        }

        public JsonResult GetOMGuidelines()
        {
            
            var OMGuidelinesList = _ctx.tblOMGuidelines.ToList();
            return Json(OMGuidelinesList, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetJtoIoData()
        {
            var jtoIO = _ctx.tblJ2IOQuestions.ToList();
            return Json(jtoIO, JsonRequestBehavior.AllowGet);
        }

        public JsonResult SaveData(string QID, string dealName, string YesNo, string Remarks) {
            bool isSuccess = false;

            using (var dbEntity = new dbPowerHouseEntities()) {

                tblJ2IOAnswers surveyTbl = new tblJ2IOAnswers();
                surveyTbl.QID = QID;
                surveyTbl.DealName = dealName;
                surveyTbl.Eid = HttpContext.Session["eid"].ToString();
                surveyTbl.Scoring = YesNo;
                surveyTbl.Remarks = Remarks;
                surveyTbl.DateAnswered = DateTime.Now.Date;
                surveyTbl.FY = "FY19";
                dbEntity.tblJ2IOAnswers.Add(surveyTbl);
                dbEntity.SaveChanges();
                isSuccess = true;
            }

            return Json(isSuccess, JsonRequestBehavior.AllowGet);
        }

        public string getFY() {

            string FY = "";

            var year = DateTime.Now.Year.ToString();
            string year2 = year.Substring(year.Length - 2);
            string month = DateTime.Now.Month.ToString();
            int monthCheker = Int32.Parse(month);
            int yearHolder = Int32.Parse(year2);
            if (monthCheker >= 9) {
                yearHolder += 1;
            }

            FY = "FY" + yearHolder.ToString();
            
            return FY;
        }
    }
}