﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Web_Portal.Models;
using Web_Portal.Filters;

namespace Web_Portal.Controllers
{
    [SessionCheck]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult ContactUs()
        {
            return View();
        }

        dbPowerHouseEntities _db = new dbPowerHouseEntities();
        public JsonResult checkMasterView() {
            

            if (HttpContext.Session["eid"] != null) {
                string eid = HttpContext.Session["eid"].ToString();
                var user = _db.tblViews.Where(v => v.Eid == eid).FirstOrDefault();
                if (user == null) {
                    tblView tblV = new tblView();
                    tblV.Eid = eid;
                    tblV.ViewVisited = "MASTER";
                    tblV.DateVisited = DateTime.Now;

                    _db.tblViews.Add(tblV);
                    _db.SaveChanges();
                }
            }

            int masterView = _db.tblViews.Count();

            return Json(masterView, JsonRequestBehavior.AllowGet);
        }

        public JsonResult checkSubPage(string ViewName) {
            if (HttpContext.Session["eid"] != null) {
                string eid = HttpContext.Session["eid"].ToString();
                var user = _db.tblViews.Where(v => v.Eid == eid && v.ViewVisited == ViewName).FirstOrDefault();
                if (user == null) {
                    tblView tblV = new tblView();
                    tblV.Eid = eid;
                    tblV.ViewVisited = ViewName;
                    tblV.DateVisited = DateTime.Now;

                    _db.tblViews.Add(tblV);
                    _db.SaveChanges();
                }
            }

            return Json(true,JsonRequestBehavior.AllowGet);
        }

        public JsonResult getSubPageCount( string viewName) {
            int subView = _db.tblViews.Where(v => v.ViewVisited == viewName).Count();

            return Json(subView, JsonRequestBehavior.AllowGet);
        }

        public JsonResult SetRating(float RatingVal) {
            string eid = HttpContext.Session["eid"].ToString();

            var Rating = _db.tblRatings.Where(r => r.eidRated == eid).FirstOrDefault();

            bool isSuccess = false;

            if (Rating == null) {
                isSuccess = true;

                tblRating rating = new tblRating();
                rating.eidRated = eid;
                rating.ratings = RatingVal;

                using (var ctx = new dbPowerHouseEntities()) {
                    ctx.tblRatings.Add(rating);
                    ctx.SaveChanges();
                }
            }
            return Json(isSuccess, JsonRequestBehavior.AllowGet);
        }
        public JsonResult ValidateRating() {
            string eid = HttpContext.Session["eid"].ToString();

            var RatingVal = _db.tblRatings.Where(r => r.eidRated == eid).FirstOrDefault();
            bool get = false;

            if (RatingVal != null) {
                get = true;
            }
            else {
                get = false;
            }

            return Json(get,JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetRating() {
            var ratingData = _db.tblRatings.ToList();

            double totalRated = ratingData.Count;
            double totalRating = 0f;

            foreach (var rate in ratingData) {
                totalRating = totalRating + rate.ratings;
            }

            double averageRating = totalRating / totalRated;

            return Json(averageRating, JsonRequestBehavior.AllowGet);
        }
    }
}