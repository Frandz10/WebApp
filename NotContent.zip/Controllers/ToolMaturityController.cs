﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Web_Portal.Models;
using Web_Portal.Filters;

namespace Web_Portal.Controllers {
    [SessionCheck]
    public class ToolMaturityController : Controller {
        // GET: ToolMaturity

        dbPowerHouseEntities _ctx = new dbPowerHouseEntities();
        public ActionResult Index() {
            return View();
        }

       
        public void openSpreadSheet() {
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo.FileName = Server.MapPath("~/files/Tool Index.xlsx");
            proc.Start();
        }

     
    }
}