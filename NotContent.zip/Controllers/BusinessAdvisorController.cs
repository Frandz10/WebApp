﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Web_Portal.Models;
using Web_Portal.Filters;

namespace Web_Portal.Controllers
{
    [SessionCheck]
    public class BusinessAdvisorController : Controller
    {
        dbPowerHouseEntities _ctx = new dbPowerHouseEntities();
        // GET: BusinessAdvisor
        public ActionResult Index() {
            return View();
        }

        //[HttpPost]
        public JsonResult LoadBa() {

            string[] totalCount;

            string[] projData = _ctx.tblBas.Select(p => p.Project).Distinct().ToArray();
            totalCount = new string[projData.Length];

            for (int i = 0; i < projData.Length; i++) {

                string projName = projData[i];

                int projCount = _ctx.tblBas.Count(p => p.Project == projName);
                totalCount[i] = projCount.ToString();
            }

            List<string[]> dataLists = new List<string[]>();

            dataLists.Add(projData);
            dataLists.Add(totalCount);

            return Json(dataLists, JsonRequestBehavior.AllowGet);
        }
    

        [HttpGet]
        public ActionResult BaList() {
            return View();
        }

        [HttpGet]
        public ActionResult TableList(string projName) {
            var Account = _ctx.tblBas.Where(e => e.Project == projName).ToList();
            return Json(Account, JsonRequestBehavior.AllowGet);
        }

       
    }
}