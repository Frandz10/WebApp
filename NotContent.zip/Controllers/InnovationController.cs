﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Web_Portal.Models;
using Web_Portal.Filters;

namespace Web_Portal.Controllers
{
   [SessionCheck]
    public class InnovationController : Controller
    {
        dbPowerHouseEntities _db = new dbPowerHouseEntities();
        // GET: Innovation
        public ActionResult Lists()
        {
            return View();
        }

        public JsonResult GetInnovation() {
            var projects = _db.tblInnovations.ToList();
            return Json(projects, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Project() {
            return View();
        }

        public JsonResult GetInnovationData(string projName) {
            var proj = _db.tblInnovations.Where(I => I.Projects == projName).FirstOrDefault();
            if (proj == null) {
                proj = _db.tblInnovations.Where(I => I.Projects.Contains(projName)).FirstOrDefault();
            }
            return Json(proj, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Collaborate() {
            return View();
        }
    }
}