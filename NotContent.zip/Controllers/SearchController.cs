﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Web_Portal.Models;
using System.Data;
using Web_Portal.Filters;

namespace Web_Portal.Controllers
{
    [SessionCheck]
    public class SearchController : Controller
    {

        private dbPowerHouseEntities db = new dbPowerHouseEntities();
        String keyword;

        // GET: Search
        public ActionResult Index(String kw)
        {
            keyword = kw;
            return View();
        }

        public JsonResult SearchItem(String keyword)
        {
            var searched = db.tblSearches.Where(x => x.Keyword.Contains(keyword)).Select(x => x).ToList();
            return Json(searched, JsonRequestBehavior.AllowGet);
        }
    }
}